import os
import cv2
import numpy as np

def black_noise(image, intensity=0.05):
    noise = np.random.randn(*image.shape) * intensity
    noisy_image = np.clip(image + noise, 0, 1)
    return (noisy_image * 255).astype(np.uint8)

def random_rain(image, num_lines=50, line_thickness=1):
    h, w, _ = image.shape
    overlay = image.copy()

    for _ in range(num_lines):
        start_x = np.random.randint(0, w)
        start_y = np.random.randint(0, h // 2)
        end_x = start_x + np.random.randint(-10, 10)
        end_y = start_y + np.random.randint(h // 2, h)
        cv2.line(overlay, (start_x, start_y), (end_x, end_y), (255, 255, 255), line_thickness)

    return cv2.addWeighted(image, 0.7, overlay, 0.3, 0)

def random_shift_scale(image, max_shift=5, max_scale=1.1):
    h, w, _ = image.shape
    scale = np.random.uniform(1, max_scale)
    shift_x = np.random.randint(-max_shift, max_shift)
    shift_y = np.random.randint(-max_shift, max_shift)

    M = np.float32([[scale, 0, shift_x],
                    [0, scale, shift_y]])
    return cv2.warpAffine(image, M, (w, h))

def random_pixel_dropout(image, dropout_ratio=0.01):
    dropout_mask = np.random.binomial(1, 1 - dropout_ratio, size=image.shape)
    return (image * dropout_mask).astype(np.uint8)

def random_blur(image, max_kernel_size=5):
    kernel_size = np.random.randint(1, max_kernel_size + 1) // 2 * 2 + 1
    return cv2.GaussianBlur(image, (kernel_size, kernel_size), 0)

def generate_synthetic_images(input_image, output_dir):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    transforms = [
        ("black_noise", black_noise),
        ("random_rain", random_rain),
        ("random_shift_scale", random_shift_scale),
        ("random_pixel_dropout", random_pixel_dropout),
        ("random_blur", random_blur),
    ]

    for transform_name, transform in transforms:
        transformed_image = transform(input_image)
        cv2.imwrite(os.path.join(output_dir, f"{transform_name}.png"), transformed_image)
        print(f"{transform_name} image saved.")

if __name__ == "__main__":
    input_image_path = "D:\\Research\\Project\\DenseO - Copy\\off_image_test\\data\\Generating data\\Simple\noise\\data\\52_00_r1l49.png"# Replace with your image path
    output_dir = "D:\\Research\\Project\\DenseO - Copy\\off_image_test\\data\\Generating data\\Simple\noise\\output"

    input_image = cv2.imread(input_image_path)
    generate_synthetic_images(input_image, output_dir)
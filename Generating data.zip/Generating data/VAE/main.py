import torch
import torchvision.transforms as transforms
from torch.optim import Adam
from torch.utils.data import DataLoader
from torchvision.utils import save_image

from image_dataset import ImageDataset
from vae_model import VAE

def vae_loss(recon_x, x, mu, logvar):
    recon_loss = nn.MSELoss()(recon_x, x)
    kl_loss = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
    return recon_loss + kl_loss

# Parameters
batch_size = 16
num_epochs = 10
learning_rate = 0.001

# Load your small dataset
data_transforms = transforms.Compose([
    transforms.Resize((64, 64)),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
])

img_dir = "/content/"
gt_file = "/content/test_new1.tsv"
dataset = ImageDataset(img_dir=img_dir, gt_file=gt_file, transform=data_transforms)
dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True, num_workers=2)

# Set device to GPU if available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Create VAE model
vae = VAE().to(device)

# Optimizer
optimizer = Adam(vae.parameters(), lr=learning_rate)

# Training loop
vae.train()
for epoch in range(num_epochs):
    epoch_loss = 0.0

    for inputs, _ in dataloader:
        inputs = inputs.to(device)

        optimizer.zero_grad()

        outputs, mu, logvar = vae(inputs)
        loss = vae_loss(outputs, inputs, mu, logvar)

        loss.backward()
        optimizer.step()

        epoch_loss += loss.item()

    print(f"Epoch {epoch + 1}, Loss: {epoch_loss / len(dataloader)}")

# Save the trained model
torch.save(vae.state_dict(), "vae_trained.pth")

# Generate a new image
vae.eval()  # Set the model to evaluation mode
with torch.no_grad():
    z = torch.randn(1, 64).to(device)
    generated_image = vae.decoder(z)

# Save the generated image
save_image(generated_image, "generated_image.png")
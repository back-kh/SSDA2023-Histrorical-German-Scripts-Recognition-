import os
from PIL import Image
from torch.utils.data import Dataset

class ImageDataset(Dataset):
    def __init__(self, img_dir, gt_file, transform=None):
        self.img_dir = img_dir
        self.transform = transform

        # Read the GT file and store the image-label pairs
        self.image_label_pairs = []
        with open(gt_file, "r") as f:
            lines = f.readlines()
            for line in lines:
                img_file, label = line.strip().split('\t')
                self.image_label_pairs.append((img_file, label))

    def __len__(self):
        return len(self.image_label_pairs)

    def __getitem__(self, idx):
        img_file, label = self.image_label_pairs[idx]
        img_path = os.path.join(self.img_dir, img_file)

        try:
            img = Image.open(img_path).convert("RGB")
        except FileNotFoundError:
            print(f"Image not found: {img_path}")
            return None, None

        if self.transform:
            img = self.transform(img)

        return img, label
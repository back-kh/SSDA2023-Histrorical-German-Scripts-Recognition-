import cv2

def convert_to_grayscale(image)
    return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

def adjust_contrast(image, alpha=1.5, beta=0)
    return cv2.convertScaleAbs(image, alpha=alpha, beta=beta)

def resize_image(image, desired_width=800)
    desired_height = int(image.shape[0]  (desired_width  image.shape[1]))
    return cv2.resize(image, (desired_width, desired_height), interpolation=cv2.INTER_AREA)

def binarize_using_otsu(image)
    _, binary_image = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return binary_image

def apply_morphological_closing(image, kernel_size=(3, 3))
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, kernel_size)
    return cv2.morphologyEx(image, cv2.MORPH_CLOSE, kernel)

def remove_small_black_noise(image, kernel_size=(3, 3))
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, kernel_size)
    return cv2.morphologyEx(image, cv2.MORPH_OPEN, kernel)
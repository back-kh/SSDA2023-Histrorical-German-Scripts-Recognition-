#The purpose of the processing pipeline is to improve the readability and prepare the images for further analysis, such as Optical Character Recognition (OCR).

#The image processing pipeline consists of the following steps:

#Converting the image to grayscale
1 Adjusting the contrast
2 Resizing the image
3 Binarization using Otsu's method
4 Applying morphological closing
5 Removing small black noise using morphological opening


Files
The project consists of the following files:

1 convert_to_grayscale.py: Function to convert an image to grayscale.
2 adjust_contrast.py: Function to adjust the contrast of an image.
3 resize_image.py: Function to resize an image.
4 binarize_using_otsu.py: Function to binarize an image using Otsu's method.
5 apply_morphological_closing.py: Function to apply morphological closing on an image.
6 remove_small_black_noise.py: Function to remove small black noise in an image using morphological opening.

Usage
To use the image processing pipeline, place all the Python files in the same directory. Then, run main.py:

python main.py
from google.colab.patches import cv2_imshow
from google.colab import files
import cv2
import image_processing as ip

def upload_image():
    uploaded = files.upload()
    file_name = list(uploaded.keys())[0]
    image = cv2.imread(file_name)
    return image

# Upload the historical document image
image = upload_image()

# Step 1: Convert to grayscale
gray_image = ip.convert_to_grayscale(image)
cv2_imshow(gray_image)

# Step 2: Contrast adjustment
contrast_image = ip.adjust_contrast(gray_image)
cv2_imshow(contrast_image)

# Step 3: Resize the image
resized_image = ip.resize_image(contrast_image)
cv2_imshow(resized_image)

# Step 4: Binarization (using Otsu's thresholding)
binary_image = ip.binarize_using_otsu(resized_image)
cv2_imshow(binary_image)

# Step 5: Apply texture solid text (morphological closing)
closed_image = ip.apply_morphological_closing(binary_image)
cv2_imshow(closed_image)

# Step 6: Clean tiny black noise (morphological opening)
opened_image = ip.remove_small_black_noise(closed_image)
cv2_imshow(opened_image)